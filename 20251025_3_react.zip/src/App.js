// React Router : 페이지 이동 기능 구현
// 리액트는 기본적으로 SPA(Single Page Application)이다. 처음에 하나의 html 페이지만
// 불러온 뒤, 그 안에서 필요한 컴포넌트만 교체하여 여러 페이지를 이동하는 듯한 
// 사용자 경험을 제공하는 방식.
// React Router는 이 SPA에서 '주소'에 따른 컴포넌트 교체(라우팅)를 손쉽게 구현하도록
// 도와주는 라이브러리.

// 1. react-router-dom 라이브러리에서 라우팅에 필요한 컴포넌트들을 import 한다.
// BrowserRouter : url를 사용하여 앱의 경로를 관리한다. => 앱 전체를 감싸야 한다.
// Routes : 여러 Route 컴포넌트를 감싸는 역할을 한다. 
// => url이 바뀌면 자식 Route들 중에서 현재 경로와 일치하는 것을 찾아 화면에 보여준다.
// Route : 경로와 컴포넌트를 짝지어주는 역할을 한다.
// => path ="/" : 루트 경로를 의미 => http://localhost:3000
// => element={컴포넌트명} : 해당 경로일때 보여줄 컴포넌트를 지정한다.
// Link : html의 <a>태그와 비슷
// => a 태그는 페이지 전체를 새로고침하지만 Link는 페이지를 새로고침 하지 않고 주소창의
//    url만 바꾼 후 해당 경로에 맞는 컴포넌트만 새로 렌더링 한다.
// => to = "이동할 경로"
import { BrowserRouter, Routes, Route, Link} from "react-router-dom";

// 2. 페이지로 사용할 컴포넌트들을 import 한다.
import Home from "./Home";
import About from "./About";



function App() {
  return (
    // 3. BrowserRouter로 전체 앱을 감싼다.
    <BrowserRouter>
      <div>
        {/* 네비게이션 메뉴 : 페이지 이동을 위한 링크들을 모아둔다. */}
        <nav>
          <ul>
            <li>
              <Link to="/">Home</Link>
            </li>
            <li>
              <Link to="/about">소개</Link>
            </li>
          </ul>
        </nav>
      </div>

    </BrowserRouter>  
  
  );
}

export default App;
