import React from "react";

export default function Home() {
  <h1>홈페이지</h1>
}