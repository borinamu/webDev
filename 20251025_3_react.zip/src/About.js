import React from "react";

export default function About() {
  <h1>소개</h1>
}